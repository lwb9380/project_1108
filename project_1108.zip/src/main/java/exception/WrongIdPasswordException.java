package exception;

public class WrongIdPasswordException extends RuntimeException {}
